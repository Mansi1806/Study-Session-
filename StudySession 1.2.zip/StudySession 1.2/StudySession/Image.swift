//
//  Image.swift
//  StudySession
//
//  Created by Jeremy Jung on 11/23/19.
//  Copyright © 2019 Jeremy Jung. All rights reserved.
//

import Foundation

struct Image: Codable {
    var image: String
}
