//
//  MySessionViewController.swift
//  StudySession
//
//  Created by Christy Song on 11/16/19.
//  Copyright © 2019 Jeremy Jung. All rights reserved.
//

import UIKit

class MySessionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "My Study Sessions"
        view.backgroundColor = .systemGray5
        // Do any additional setup after loading the view.
    }
    


}
